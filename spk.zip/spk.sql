-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.33 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for spk
CREATE DATABASE IF NOT EXISTS `spk` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `spk`;

-- Dumping structure for table spk.m_log
CREATE TABLE IF NOT EXISTS `m_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_user` varchar(50) DEFAULT NULL,
  `log_tipe` int(2) DEFAULT NULL,
  `log_desc` varchar(50) DEFAULT NULL,
  `log_browser` varchar(50) DEFAULT NULL,
  `log_os` varchar(50) DEFAULT NULL,
  `log_ip` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_log: ~19 rows (approximately)
/*!40000 ALTER TABLE `m_log` DISABLE KEYS */;
INSERT INTO `m_log` (`id`, `log_user`, `log_tipe`, `log_desc`, `log_browser`, `log_os`, `log_ip`) VALUES
	(1, 'aku', 1, 'Logout user', 'Chrome 99.0.4844.51', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(2, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.51', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(3, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(4, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(5, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(6, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(7, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(8, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(9, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(10, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(11, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(12, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(13, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(14, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(15, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(16, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(17, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(18, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(19, 'hoirul', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(20, 'hoirul', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(21, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(22, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(23, 'Hoirul Rhojiqin', 1, 'Logout user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(24, 'Nur Rezky Rahmani', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1'),
	(25, 'Hoirul Rhojiqin', 0, 'Login user', 'Chrome 99.0.4844.74', 'Windows 10', '127.0.0.1:127.0.0.1');
/*!40000 ALTER TABLE `m_log` ENABLE KEYS */;

-- Dumping structure for table spk.m_user
CREATE TABLE IF NOT EXISTS `m_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `aktif` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_user: ~3 rows (approximately)
/*!40000 ALTER TABLE `m_user` DISABLE KEYS */;
INSERT INTO `m_user` (`id`, `username`, `password`, `nama`, `role`, `status`, `role_id`, `created_at`, `updated_at`, `aktif`) VALUES
	(10, 'irul', '202cb962ac59075b964b07152d234b70', 'hoirul', 'admin', 1, 1, '2022-03-14 16:00:41', NULL, 1),
	(11, 'kiki', '0d61130a6dd5eea85c2c5facfe1c15a7', 'Nur Rezki Rahmani', 'mahasiswa', 1, 3, '2022-03-14 16:32:34', NULL, 1),
	(12, 'aku', '4f3a88a76cd61944a3f35cff17503624', 'Hoirul Rhojiqin', 'mahasiswa', 1, 1, '2022-03-14 17:44:14', NULL, 1);
/*!40000 ALTER TABLE `m_user` ENABLE KEYS */;

-- Dumping structure for table spk.m_user_detail
CREATE TABLE IF NOT EXISTS `m_user_detail` (
  `id` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `no_hp` varchar(50) DEFAULT NULL,
  `alamat` text,
  `tentang_saya` text,
  `link_image` text,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table spk.m_user_detail: ~0 rows (approximately)
/*!40000 ALTER TABLE `m_user_detail` DISABLE KEYS */;
INSERT INTO `m_user_detail` (`id`, `id_user`, `email`, `tgl_lahir`, `gender`, `no_hp`, `alamat`, `tentang_saya`, `link_image`) VALUES
	(0, 12, 'insangrafi@gmail.com', '2022-03-14', 'pria', '323232', 'Eart', 'Hobi Jalan', NULL),
	(1, 10, 'hoirul1995@gmail.com', '1995-10-09', 'pria', '081334431144', 'Jln Minasa Upa Blok L10 No.13', 'Hobi Jalan dan Suka Motret', NULL);
/*!40000 ALTER TABLE `m_user_detail` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
